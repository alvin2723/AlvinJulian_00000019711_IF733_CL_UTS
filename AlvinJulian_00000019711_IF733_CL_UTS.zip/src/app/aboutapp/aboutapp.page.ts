import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutapp',
  templateUrl: './aboutapp.page.html',
  styleUrls: ['./aboutapp.page.scss'],
})
export class AboutappPage implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
